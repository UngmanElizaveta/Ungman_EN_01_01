package com.example.ungmanen_01_01

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class Main_Activity:AppCompatActivity()
{
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.second_activity)
    }
}