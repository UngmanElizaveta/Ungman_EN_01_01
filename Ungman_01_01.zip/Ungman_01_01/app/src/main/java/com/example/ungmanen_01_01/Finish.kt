package com.example.ungmanen_01_01
import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class Finish: AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.result)

        val editTextInput: EditText = findViewById(R.id.EditTextOne)
        val editTextBytes: EditText = findViewById(R.id.EditTextTwo)
        val editTextKilobytes: EditText = findViewById(R.id.EditTextThree)
        val editTextResult: EditText = findViewById(R.id.EditTextFour)

        val buttonCalculate: Button = findViewById(R.id.Vichislit)
        val buttonHome: Button = findViewById(R.id.Home)

        buttonCalculate.setOnClickListener {
            val inputText = editTextInput.text.toString().trim()
            if (inputText.isEmpty()) {
                Toast.makeText(this, "Введите число", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            try {
                val number = inputText.toDouble()

                // Переводим в байты и килобайты
                val bytes = number
                val kilobytes = number / 1024.0

                // Устанавливаем значения в поля (для информации)
                editTextBytes.setText(bytes.toString())
                editTextKilobytes.setText(String.format("%.4f", kilobytes))

                // Результат: отображаем например, в формате: "X байт = Y килобайт"
                val resultText = "$bytes байт = ${String.format("%.4f", kilobytes)} килобайт"
                editTextResult.setText(resultText)

            } catch (e: NumberFormatException) {
                Toast.makeText(this, "Некорректный ввод", Toast.LENGTH_SHORT).show()
            }
        }

        buttonHome.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
    }
}