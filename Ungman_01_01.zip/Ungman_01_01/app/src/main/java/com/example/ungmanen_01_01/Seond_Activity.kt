package com.example.ungmanen_01_01
import  androidx.appcompat.app.AppCompatActivity

class Seond_Activity {

}
